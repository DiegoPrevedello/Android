package com.example.tictactoe;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.content.Intent;
import android.graphics.Color;

public class MainActivity extends AppCompatActivity {

    static final int ACTIVITY_GAME = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button gioca_X = findViewById(R.id.giocaX);
        Button gioca_O = findViewById(R.id.giocaO);
        Button start = findViewById(R.id.play);
        Intent i = new Intent();

        gioca_X.setOnClickListener(
                (View) -> {
                    Bundle extras = new Bundle();
                    extras.putBoolean("turnGame", true);
                    i.putExtras(extras);

                    start.setEnabled(true);
                }
        );

        gioca_O.setOnClickListener(
                (View) -> {
                    Bundle extras = new Bundle();
                    extras.putBoolean("turnGame",false);
                    i.putExtras(extras);

                    start.setEnabled(true);
                }
        );

        start.setOnClickListener(
                (View) -> {
                    Intent i3 = new Intent(this, GameActivity.class);
                    i3.putExtras(i);
                    Bundle extras = new Bundle();
                    extras.putInt("game", -1);
                    i3.putExtras(extras);
                    System.out.println("MAZZUNARAGAZZI");
                    startActivityForResult(i3, ACTIVITY_GAME);

                }
        );

    }
}
